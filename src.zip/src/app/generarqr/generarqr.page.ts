import { Component, OnInit } from '@angular/core';
import { MenuController } from '@ionic/angular';
import { AlertController } from '@ionic/angular';

@Component({
  selector: 'app-generarqr',
  templateUrl: './generarqr.page.html',
  styleUrls: ['./generarqr.page.scss'],
})
export class GenerarqrPage implements OnInit {

  qrCodeString= 'Hola Mundo'; 
  date = new Date().toLocaleDateString('es-es', { weekday:"long", year:"numeric", month:"long", day:"numeric"}) ;
  scannedResult:any;


  constructor(private menuController: MenuController,
              private alertController: AlertController) { }

  ngOnInit() {
  }


  mostrarMenu(){
    this.menuController.open('first');
  }

  usuario={
    seccion:'',
  }


  generaScan(){
    this.qrCodeString= this.usuario.seccion.concat(' '+ this.date);
  }

  verScan(){
    this.scannedResult=this.qrCodeString;
  }

  async presentAlert() {
    const alert = await this.alertController.create({
      header: 'Alerta',
      message: 'La asistencia se ha registrado correctamente!',
      buttons: ['OK'],
    });

    await alert.present();
  }
}
import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-seleccion',
  templateUrl: './seleccion.page.html',
  styleUrls: ['./seleccion.page.scss'],
})
export class SeleccionPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

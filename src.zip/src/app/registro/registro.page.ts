import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators,FormBuilder } from '@angular/forms';
import { RegistroserviceService, Usuario } from '../services/registroservice.service';
import { ToastController, AlertController } from '@ionic/angular';
import { Router } from '@angular/router';

@Component({
  selector: 'app-registro',
  templateUrl: './registro.page.html',
  styleUrls: ['./registro.page.scss'],
})
export class RegistroPage implements OnInit {

  formularioRegistro: FormGroup;
  nuevoRegistro: Usuario = <Usuario>{};
  usuarios:Usuario[]=[];

  constructor(
    public fb: FormBuilder,
    private router: Router,
    private toastController: ToastController,
    private registroService: RegistroserviceService,
    private alertController: AlertController,
    ) { 
    this.formularioRegistro = this.fb.group({
      'nombre': new FormControl("",Validators.required),
      'fecha': new FormControl("",Validators.required),
      'correo': new FormControl("",Validators.email),
      'password': new FormControl("",Validators.required),
      'confirmacionPassword': new FormControl("", Validators.required),
      'tipo': new FormControl("", Validators.required)
    });
  }

  ngOnInit() {
  }

  async registrarse(){
    
    var form = this.formularioRegistro.value;
    if(this.formularioRegistro.invalid){
      this.alert('ERROR','Debe ingresar todos los datos');
      return ;
    }
    if(form.password == form.confirmacionPassword){
      this.nuevoRegistro.nombre = form.nombre;
      this.nuevoRegistro.correo = form.correo;
      this.nuevoRegistro.fecha = form.fecha; 
      this.nuevoRegistro.password = form.password;
      this.nuevoRegistro.profesor = form.tipo;
      this.registroService.getUsuarios().then(async datos=> {
        this.usuarios=datos;
        if(datos==null){
          this.registroService.addUsuario(this.nuevoRegistro).then(dato =>{
            this.nuevoRegistro = <Usuario>{};
            this.showToast('Usuario Creado con éxito!');
            this.router.navigateByUrl('/loginprofesor');
          });
        }
        else{
      for(let obj of this.usuarios){
        if(obj.correo==this.nuevoRegistro.correo){
          this.alert('ERROR','El correo que intentas registrar ya tiene usuario.');
          return ;
        }
      else{
        this.registroService.addUsuario(this.nuevoRegistro).then(dato =>{
          this.nuevoRegistro = <Usuario>{};
          this.showToast('Usuario Creado con éxito!');
          this.router.navigateByUrl('/loginprofesor');
        });
      }
      }
    }
    });
    }
    else{
      this.alert('ERROR','Las contraseñas deben coincidir');
      return ;
    }
  }

async alert(hdr,msg){
  const alert=await this.alertController.create({
    header: hdr,
    message: msg,
    buttons: ['Aceptar'],
  });
  await alert.present();
  return;
}

  async showToast(msg){
    const toast = await this.toastController.create({
      message: msg,
      duration: 2000
    })
    toast.present();
  }

}
